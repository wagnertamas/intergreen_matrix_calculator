import gymnasium as gym
from gymnasium import spaces
import numpy as np
import json
import os
import sys
import subprocess
import random

# libsumo használata
try:
    import libsumo as traci
    USE_LIBSUMO = True
except ImportError:
    raise ImportError("Hiba: A 'libsumo' modul nem található! Ellenőrizd a PYTHONPATH-t vagy a SUMO_HOME-ot.")


class SumoRLEnvironment(gym.Env):
    """
    Egyszerűsített, Single-Instance Multi-Agent RL Környezet.
    """
    def __init__(self,
                 net_file,
                 logic_json_file,
                 detector_file,
                 route_file="random_traffic.rou.xml",
                 reward_weights={'time': 1.0, 'co2': 1.0},
                 min_green_time=5,
                 delta_time=5,
                 measure_during_transition=False,
                 sumo_gui=False,
                 random_traffic=True,
                 traffic_period=1.0,
                 traffic_duration=3600,
                 statistic_output_file=None):

        self.net_file = net_file
        self.logic_json_file = logic_json_file
        self.detector_file = detector_file
        self.route_file = route_file
        self.statistic_output_file = statistic_output_file

        self.reward_weights = reward_weights
        self.min_green_time = min_green_time
        self.delta_time = int(delta_time)
        self.measure_during_transition = measure_during_transition
        self.sumo_gui = sumo_gui
        self.random_traffic = random_traffic
        self.traffic_period = traffic_period
        self.traffic_duration = traffic_duration

        with open(self.logic_json_file, 'r') as f:
            self.logic_data = json.load(f)

        self.junction_ids = list(self.logic_data.keys())

        # Ágensek létrehozása
        self.agents = {
            jid: TrafficAgent(jid, self.logic_data[jid], min_green_time, measure_during_transition)
            for jid in self.junction_ids
        }
        
        self.observation_space = None
        self.action_space = None
        self.is_running = False

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)

        # 1. Random forgalom generálás (USER REQUEST: SŰRŰ FORGALOM VISSZAÁLLÍTÁSA)
        if self.random_traffic:
            # Visszaállítva a kért extrém sűrűségre
            dynamic_period = round(random.uniform(0.001, 0.005), 4)
            self.generate_random_traffic(period=dynamic_period)

        # 2. SUMO parancs összeállítása
        sumo_args = [
            "-n", self.net_file,
            "-r", self.route_file,
            "-a", self.detector_file,
            "--no-step-log", "true",
            "--waiting-time-memory", "10000",
            "--ignore-route-errors", "true",
            "--random", "true",
            "--no-warnings", "true",
            "--xml-validation", "never"
        ]

        if self.statistic_output_file:
            sumo_args.extend([
                "--statistic-output", self.statistic_output_file,
                "--duration-log.statistics", "true"
            ])

        # 3. SUMO indítása (libsumo start vs load trükk)
        if self.is_running:
            traci.load(sumo_args)
        else:
            traci.start(["sumo"] + sumo_args)
            self.is_running = True

        self._map_network_elements()
        
        # 4. Terek beállítása
        if self.observation_space is None:
             self.observation_space = spaces.Dict({
                 jid: self.agents[jid].observation_space for jid in self.agents.keys()
             })
             self.action_space = spaces.Dict({
                 jid: self.agents[jid].action_space for jid in self.agents.keys()
             })

        # 5. Warm-up
        warmup_seconds = random.randint(100, 300)
        if options and 'warmup_seconds' in options:
            warmup_seconds = options['warmup_seconds']

        for _ in range(warmup_seconds):
            for agent in self.agents.values():
                agent.collect_measurements() 
                agent.update_logic()
                if agent.is_ready_for_action():
                     agent.set_target_phase(random.randint(0, agent.num_phases - 1))
            traci.simulationStep()

        for agent in self.agents.values():
            agent.reset_step_metrics()

        observations = {jid: agent.get_observation() for jid, agent in self.agents.items()}
        infos = {jid: {"ready": agent.is_ready_for_action()} for jid in self.junction_ids}

        return observations, infos

    def generate_random_traffic(self, period):
        print(f"Forgalom generálása (Period={period})...")
        if 'SUMO_HOME' in os.environ:
            tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
            sys.path.append(tools)
        else:
            try:
                import sumolib
                tools = os.path.join(os.path.dirname(sumolib.__file__), '..', '..', 'tools')
            except:
                return 

        random_trips_script = os.path.join(tools, "randomTrips.py")
        cmd = [
            sys.executable, random_trips_script,
            "-n", self.net_file,
            "-o", self.route_file,
            "-e", str(self.traffic_duration),
            "-p", str(period),
            "--fringe-factor", "10",
            "--validate",
            "--min-distance", "50",
            "--duarouter-routing-algorithm", "CH",
            "--duarouter-routing-threads", "4",
        ]
        try:
            # subprocess.PIPE helyett DEVNULL, hogy ne szemetelje tele a logot
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            print(f"HIBA a randomTrips-nél: {e}")

    def _map_network_elements(self):
        all_loops = traci.inductionloop.getIDList()
        for jid, agent in self.agents.items():
            agent.reset_step_metrics()
            agent.reset_logic()

            controlled_links = traci.trafficlight.getControlledLinks(jid)
            incoming_lanes_set = set()
            for link_group in controlled_links:
                for link in link_group:
                    if link: incoming_lanes_set.add(link[0])
            agent.incoming_lanes = list(incoming_lanes_set)

            temp_detectors = []
            for loop in all_loops:
                lane_id = traci.inductionloop.getLaneID(loop)
                if lane_id in incoming_lanes_set:
                    temp_detectors.append(loop)

            agent.detectors = sorted(temp_detectors)
            agent.setup_spaces()
            agent.reset_step_metrics()

    def step(self, actions):
        if not self.is_running:
            raise RuntimeError("Szimuláció nem fut.")

        for jid, action in actions.items():
            self.agents[jid].set_target_phase(int(action))

        for agent in self.agents.values():
            agent.reset_step_metrics()

        for _ in range(self.delta_time):
            for agent in self.agents.values():
                agent.update_logic()
            traci.simulationStep()
            for agent in self.agents.values():
                agent.collect_measurements()

        observations = {}
        rewards = {}
        dones = {}
        infos = {}
        
        sim_terminated = (traci.simulation.getMinExpectedNumber() <= 0)
        sim_truncated = (traci.simulation.getTime() >= self.traffic_duration)
        global_done = sim_terminated or sim_truncated

        w_time = self.reward_weights.get('time', 1.0)
        w_co2 = self.reward_weights.get('co2', 1.0)

        MU_TIME  = 11.211313
        STD_TIME = 1.129861
        MU_CO2   = 0.483506
        STD_CO2  = 0.121195

        for jid, agent in self.agents.items():
            observations[jid] = agent.get_observation()
            
            avg_travel_time = agent.get_avg_travel_time_metric()
            total_co2 = agent.get_total_co2_metric()

            z_time = (np.log(avg_travel_time + 1e-5) - MU_TIME) / (STD_TIME + 1e-9)
            z_co2  = (np.log(total_co2 + 1e-5) - MU_CO2)  / (STD_CO2  + 1e-9)
            
            score_time = 1 / (1 + np.exp(-z_time))
            score_co2  = 1 / (1 + np.exp(-z_co2))
            
            r_time = 1.0 - score_time
            r_co2  = 1.0 - score_co2
            
            rewards[jid] = w_time * r_time + w_co2 * r_co2
            
            infos[jid] = {
                "ready": agent.is_ready_for_action(),
                "metric_travel_time": avg_travel_time,
                "metric_co2": total_co2,
            }
            dones[jid] = global_done

        return observations, rewards, global_done, False, infos

    def close(self):
        if self.is_running:
            try:
                traci.close()
            except:
                pass
            self.is_running = False


class TrafficAgent:
    """
    TrafficAgent változatlan.
    """
    def __init__(self, jid, logic_data, min_green_time, measure_during_transition):
        self.jid = jid
        self.min_green_const = min_green_time
        
        self.phase_registry = {}
        if 'phases' in logic_data:
            for p in logic_data['phases']:
                self.phase_registry[p['index']] = {'state': p['state'], 'duration': float(p['duration'])}
        
        self.logic_phases = {int(k): v for k, v in logic_data['logic_phases'].items()}
        self.transitions = logic_data['transitions']
        self.num_phases = len(self.logic_phases)

        self.detectors = []
        self.incoming_lanes = []
        self.det_accumulated_flow = {}
        self.det_accumulated_occ = {}
        self.reset_logic()
        self.reset_step_metrics()
        
        self.action_space = None
        self.observation_space = None

    def reset_logic(self):
        self.current_logic_idx = 0
        self.target_logic_idx = 0
        self.is_transitioning = False
        self.transition_queue = []
        self.transition_cursor = 0
        self.transition_step_timer = 0
        self.min_green_timer = 0
        self.current_sumo_state = "??????"

    def setup_spaces(self):
        num_detectors = len(self.detectors)
        self.action_space = spaces.Discrete(self.num_phases)
        self.observation_space = spaces.Dict({
            "phase": spaces.Box(low=0, high=self.num_phases-1, shape=(1,), dtype=np.int32),
            "occupancy": spaces.Box(low=0, high=1, shape=(num_detectors,), dtype=np.float32),
            "flow": spaces.Box(low=0, high=np.inf, shape=(num_detectors,), dtype=np.float32)
        })

    def reset_step_metrics(self):
        self.steps_measured = 0
        self.det_accumulated_flow = {d: 0 for d in self.detectors}
        self.det_accumulated_occ = {d: 0.0 for d in self.detectors}
        self.accumulated_travel_time = 0.0
        self.accumulated_co2 = 0.0

    def is_ready_for_action(self):
        return (not self.is_transitioning) and (self.min_green_timer <= 0)

    def set_target_phase(self, target_idx):
        if self.is_ready_for_action():
            if target_idx in self.logic_phases:
                self.target_logic_idx = target_idx

    def update_logic(self):
        if self.is_transitioning:
            if self.transition_step_timer > 0:
                self.transition_step_timer -= 1
            else:
                if self.transition_cursor < len(self.transition_queue):
                    sumo_idx = self.transition_queue[self.transition_cursor]
                    if sumo_idx in self.phase_registry:
                        p = self.phase_registry[sumo_idx]
                        self.current_sumo_state = p['state']
                        traci.trafficlight.setRedYellowGreenState(self.jid, p['state'])
                        self.transition_step_timer = max(0, int(p['duration']) - 1)
                    self.transition_cursor += 1
                else:
                    self.is_transitioning = False
                    self.current_logic_idx = self.next_logic_idx_cache
                    self._apply_current_phase()
                    self.min_green_timer = self.min_green_const
        else:
            if self.min_green_timer > 0:
                self.min_green_timer -= 1
                self._apply_current_phase()
            else:
                if self.target_logic_idx != self.current_logic_idx:
                    self._start_transition(self.target_logic_idx)
                else:
                    self._apply_current_phase()

    def _apply_current_phase(self):
        if self.current_logic_idx in self.logic_phases:
            sumo_idx = self.logic_phases[self.current_logic_idx]
            if sumo_idx in self.phase_registry:
                state = self.phase_registry[sumo_idx]['state']
                self.current_sumo_state = state
                traci.trafficlight.setRedYellowGreenState(self.jid, state)

    def _start_transition(self, next_idx):
        key = f"{self.current_logic_idx}->{next_idx}"
        self.transition_queue = self.transitions.get(key, [])
        self.is_transitioning = True
        self.transition_cursor = 0
        self.transition_step_timer = 0
        self.next_logic_idx_cache = next_idx

    def collect_measurements(self):
        self.steps_measured += 1
        for det_id in self.detectors:
            self.det_accumulated_flow[det_id] += traci.inductionloop.getLastStepVehicleNumber(det_id)
            self.det_accumulated_occ[det_id] += traci.inductionloop.getLastStepOccupancy(det_id)
            
        step_tt = 0.0
        step_co2 = 0.0
        for lane in self.incoming_lanes:
            step_tt += traci.lane.getTraveltime(lane)
            step_co2 += traci.lane.getCO2Emission(lane)
        self.accumulated_travel_time += step_tt
        self.accumulated_co2 += step_co2

    def get_observation(self):
        num_dets = len(self.detectors)
        if num_dets == 0:
             return {}
             
        occ = np.zeros(num_dets, dtype=np.float32)
        flow = np.zeros(num_dets, dtype=np.float32)
        if self.steps_measured > 0:
            for i, det in enumerate(self.detectors):
                occ[i] = (self.det_accumulated_occ[det] / self.steps_measured) / 100.0
                flow[i] = (self.det_accumulated_flow[det] / self.steps_measured)
        
        return {
            "phase": np.array([self.current_logic_idx], dtype=np.int32),
            "occupancy": occ,
            "flow": flow
        }

    def get_avg_travel_time_metric(self):
        return (self.accumulated_travel_time / self.steps_measured) if self.steps_measured > 0 else 0.0

    def get_total_co2_metric(self):
        return ((self.accumulated_co2 / 1000.0) / self.steps_measured) if self.steps_measured > 0 else 0.0